# Cypress Test Suite — EnrichMinion

Automated end-to-end tests for EnrichMinion  
URL under test: https://enrichminion.vercel.app/enrichment/phone-finder

This project verifies UI flows such as:
- Login
- File upload (CSV)
- Navigation & basic validation flows

---

## ✅ Prerequisites
- Node.js (v14+ recommended)
- npm
- Internet access to the app

---

## 📂 Project Structure

cypress/
├─ e2e/
│ ├─ spec.cy.js
├─ fixtures/
│ └─ Test_File.csv
├─ support/
├  └─ e2e.js
cypress.config.js
package.json
README.md

1. Clone or create your project folder and `cd` into it:
   ```bash
   mkdir cypress
   cd cypress

2. Initialize & install Cypress:
    npm init -y
    npm install cypress --save-dev

3. Install file-upload plugin (required for CSV tests):
    npm install --save-dev cypress-file-upload

4. Open Cypress once to create folders:
    npx cypress open

5. Import helpers & plugins:
    cypress/support/e2e.js
    add import 'cypress-file-upload' 

6. Place test files in cypress/fixtures/:
    cypress/fixtures/Test_File.csv

7. Run your test
    npx cypress open
