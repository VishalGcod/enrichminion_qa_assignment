describe("Register Test valid scenario", () => {
  it("should show error for invalid login", () => {
    cy.visit("https://enrichminion.vercel.app/enrichment/phone-finder");
    cy.contains("Register").click();
    cy.wait(1000);
    cy.contains("Login").click();
    cy.wait(1000);
    cy.contains("Register").click();
    cy.wait(1000);
    cy.get('input[type="email"]')
      .filter(":visible")
      .eq(1)
      .type("testwrong@mail.com");
    cy.get('input[type="password"]').filter(":visible").eq(1).type("wrong123");
    cy.contains(/Register/i).click();
    cy.wait(1000);
  });
});

describe("Register Test Invalid scenario", () => {
  it("should show error for invalid login", () => {
    cy.visit("https://enrichminion.vercel.app/enrichment/phone-finder");
    cy.contains("Register").click();
    cy.wait(1000);
    cy.get('input[type="email"]').filter(":visible").eq(1).type("wrong123");
    cy.get('input[type="password"]').filter(":visible").eq(1);
    cy.contains(/Register/i).click();
    cy.wait(1000);
  });
});

describe("Password reset Positive scenario", () => {
  it("should show error for invalid login", () => {
    cy.visit("https://enrichminion.vercel.app/enrichment/phone-finder");
    cy.get("button").contains("Forgot Password?").click();
    cy.wait(1000);
    cy.get('input[type="email"]')
      .filter(":visible")
      .eq(0)
      .type("jayashreeganesan30@gmail.com");
    cy.wait(1000);
    cy.get("button").contains("Send Password Reset Link").click();
    cy.wait(1000);
  });
});

describe("Password reset Negative scenario", () => {
  it("should show error for invalid login", () => {
    cy.visit("https://enrichminion.vercel.app/enrichment/phone-finder");
    cy.get("button").contains("Forgot Password?").click();
    cy.get("button").contains("Send Password Reset Link").click();
    cy.wait(1000);
  });
});

describe("Login Test Invalid scenario", () => {
  it("should show error for invalid login", () => {
    cy.visit("https://enrichminion.vercel.app/enrichment/phone-finder");
    cy.get('input[type="email"]')
      .filter(":visible")
      .eq(0)
      .type("testwrong@mail.com");
    cy.get('input[type="password"]').filter(":visible").eq(0).type("wrong123");
    cy.get("button").contains("Login").click();
    cy.wait(1000);
  });
});

describe("Login Test Valid scenario", () => {
  it("should show error for invalid login", () => {
    cy.visit("https://enrichminion.vercel.app/enrichment/phone-finder");
    cy.get('input[type="email"]')
      .filter(":visible")
      .eq(0)
      .type("jayashreeganesan30@gmail.com");
    cy.get('input[type="password"]').filter(":visible").eq(0).type("Pooja@123");
    cy.get("button").contains("Login").click();
    cy.wait(3000);
  });
});

describe("Login and upload file", () => {
  it("should show error for invalid login", () => {
    cy.visit("https://enrichminion.vercel.app/enrichment/phone-finder");
    cy.get('input[type="email"]')
      .filter(":visible")
      .eq(0)
      .type("jayashreeganesan30@gmail.com");
    cy.get('input[type="password"]').filter(":visible").eq(0).type("Pooja@123");
    cy.get("button").contains("Login").click();
    cy.wait(1000);
    const xlData = "Test_File.csv";
    cy.get("#file").attachFile(xlData);
    cy.wait(1000);
    cy.get("button").contains("Continue to map columns").click();
    cy.wait(1000);
  });
});